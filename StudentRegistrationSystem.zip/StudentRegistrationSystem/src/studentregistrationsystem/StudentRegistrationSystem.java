/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentregistrationsystem;

/**
 *
 * @author Keketso Six
 */

import java.util.*;

class Student implements Comparable<Student> {
    private int studentId;
    private String name;
    private String department;
    private int yearOfStudy;

    public Student(int studentId, String name, String department, int yearOfStudy) {
        this.studentId = studentId;
        this.name = name;
        this.department = department;
        this.yearOfStudy = yearOfStudy;
    }

    public int getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public int getYearOfStudy() { return yearOfStudy; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student student = (Student) o;
        return studentId == student.studentId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(studentId);
    }

    @Override
    public String toString() {
        return "ID: " + studentId + ", Name: " + name + ", Dept: " + department + ", Year: " + yearOfStudy;
    }

    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.studentId, other.studentId);
    }
}

class StudentRoster {
    private Map<Integer, Student> students;

    public StudentRoster() {
        students = new HashMap<>();
    }

    public void addStudent(Student student) {
        students.put(student.getStudentId(), student);
    }

    public Student getStudent(int studentId) {
        return students.get(studentId);
    }

    public void displayAllStudents() {
        System.out.println("\n--- All Students in Roster ---");
        for (Student s : students.values()) {
            System.out.println(s);
        }
    }

    public List<Student> getStudentsByDepartmentSortedByName(String department) {
        List<Student> result = new ArrayList<>();

        for (Student s : students.values()) {
            if (s.getDepartment().equalsIgnoreCase(department)) {
                result.add(s);
            }
        }

        result.sort(Comparator.comparing(Student::getName));
        return result;
    }
}

public class StudentRegistrationSystem {
    public static void main(String[] args) {
        // Create roster
        StudentRoster roster = new StudentRoster();

        // Add students
        roster.addStudent(new Student(101, "Alice", "Computer Science", 1));
        roster.addStudent(new Student(102, "Bob", "Mathematics", 2));
        roster.addStudent(new Student(103, "Charlie", "Computer Science", 3));
        roster.addStudent(new Student(104, "Diana", "Physics", 1));
        roster.addStudent(new Student(105, "Evan", "Computer Science", 4));

        // Display all students
        roster.displayAllStudents();

        // Departmental report
        System.out.println("\n--- Computer Science Department Report (Sorted by Name) ---");
        List<Student> csStudents = roster.getStudentsByDepartmentSortedByName("Computer Science");
        for (Student s : csStudents) {
            System.out.println(s);
        }

        // Registration queue simulation
        System.out.println("\n--- Registration Queue Simulation ---");
        Queue<Student> registrationQueue = new LinkedList<>();
        registrationQueue.addAll(Arrays.asList(
                new Student(201, "Frank", "Mathematics", 1),
                new Student(202, "Grace", "Computer Science", 2),
                new Student(203, "Hannah", "Physics", 3),
                new Student(204, "Ian", "Computer Science", 1),
                new Student(205, "Jack", "Mathematics", 4)
        ));

        while (!registrationQueue.isEmpty()) {
            Student current = registrationQueue.poll();
            System.out.println("Processing registration for " + current.getName() + "...");
        }
    }
}
